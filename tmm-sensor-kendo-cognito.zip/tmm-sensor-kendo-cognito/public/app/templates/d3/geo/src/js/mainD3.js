
export default function mainD3() {
  console.log("Main D3 Loaded! with div component ... ");

 
}