'use strict';

// Define the `core.post` module
angular.module('core.post', ['ngResource']);
