'use strict';

// Define the `postList` module
angular.module('postList', ['core.post']);
