'use strict';

// Define the `postDetail` module
angular.module('postDetail', [
  'ngRoute',
  'core.post'
]);
