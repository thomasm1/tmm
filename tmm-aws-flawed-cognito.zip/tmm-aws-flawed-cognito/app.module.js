'use strict';

// Define the `postcatApp` module
angular.module('postcatApp', [
  'ngAnimate',
  'ngRoute',
  'core',
  'postDetail',
  'postList'
]);
