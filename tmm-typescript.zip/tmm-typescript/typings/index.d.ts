/// <reference path="globals/angular-mocks/index.d.ts" />
/// <reference path="globals/angular/index.d.ts" />
/// <reference path="globals/jasmine/index.d.ts" />
/// <reference path="globals/jquery/index.d.ts" />
/// <reference path="globals/node/index.d.ts" />
/// <reference path="modules/angular-mocks/index.d.ts" />
/// <reference path="modules/bluebird/index.d.ts" />
