'use strict';
var dogsrus;
(function (dogsrus) {
    var virtdog;
    (function (virtdog) {
        angular.module('app.core', [
            /*
              * Angular modules
              */
            'ngRoute'
        ]);
        function getModuleCore() {
            return angular.module('app.core');
        }
        virtdog.getModuleCore = getModuleCore;
    })(virtdog = dogsrus.virtdog || (dogsrus.virtdog = {}));
})(dogsrus || (dogsrus = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29yZS5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJjb3JlLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxZQUFZLENBQUM7QUFDYixJQUFVLE9BQU8sQ0FtQmhCO0FBbkJELFdBQVUsT0FBTztJQUFDLElBQUEsT0FBTyxDQW1CeEI7SUFuQmlCLFdBQUEsT0FBTyxFQUFDLENBQUM7UUFDekIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUU7WUFDekI7O2dCQUVJO1lBQ0osU0FBUztTQVVWLENBQUMsQ0FBQztRQUNIO1lBQ0UsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDcEMsQ0FBQztRQUZlLHFCQUFhLGdCQUU1QixDQUFBO0lBQ0gsQ0FBQyxFQW5CaUIsT0FBTyxHQUFQLGVBQU8sS0FBUCxlQUFPLFFBbUJ4QjtBQUFELENBQUMsRUFuQlMsT0FBTyxLQUFQLE9BQU8sUUFtQmhCIn0=