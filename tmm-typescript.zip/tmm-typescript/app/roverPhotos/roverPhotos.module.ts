﻿'use strict';
namespace dogsrus.virtdog {
  angular.module('app.roverPhotos', []);
  export function getModuleRoverPhotos(): ng.IModule {
    return angular.module('app.roverPhotos');
  }
}
