'use strict';
var dogsrus;
(function (dogsrus) {
    var virtdog;
    (function (virtdog) {
        angular.module('app.dogObject', []);
        function getModuleDogObject() {
            return angular.module('app.dogObject');
        }
        virtdog.getModuleDogObject = getModuleDogObject;
    })(virtdog = dogsrus.virtdog || (dogsrus.virtdog = {}));
})(dogsrus || (dogsrus = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZG9nT2JqZWN0Lm1vZHVsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRvZ09iamVjdC5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsWUFBWSxDQUFDO0FBQ2IsSUFBVSxPQUFPLENBS2hCO0FBTEQsV0FBVSxPQUFPO0lBQUMsSUFBQSxPQUFPLENBS3hCO0lBTGlCLFdBQUEsT0FBTyxFQUFDLENBQUM7UUFDekIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDcEM7WUFDRSxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUN6QyxDQUFDO1FBRmUsMEJBQWtCLHFCQUVqQyxDQUFBO0lBQ0gsQ0FBQyxFQUxpQixPQUFPLEdBQVAsZUFBTyxLQUFQLGVBQU8sUUFLeEI7QUFBRCxDQUFDLEVBTFMsT0FBTyxLQUFQLE9BQU8sUUFLaEIifQ==