﻿'use strict';
namespace dogsrus.virtdog {
  angular.module('app.dogObject', []);
  export function getModuleDogObject(): ng.IModule {
    return angular.module('app.dogObject');
  }
}
