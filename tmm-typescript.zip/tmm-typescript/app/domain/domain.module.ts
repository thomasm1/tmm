﻿'use strict';
namespace dogsrus.virtdog {
  angular.module('app.dogDomain', []);
  export function getModuleDogDomain(): ng.IModule {
    return angular.module('app.dogDomain');
  }
}
