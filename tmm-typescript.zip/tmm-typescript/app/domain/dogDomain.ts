'use strict';
namespace dogsrus.virtdog {
  export class DogDomain {
    public name = '';
    public indoors = true;
    public imagePath = '';
    public placeObjects: DogObject[] = [];
  }
}
