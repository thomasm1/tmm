'use strict';
var dogsrus;
(function (dogsrus) {
    var virtdog;
    (function (virtdog) {
        var DogDomain = (function () {
            function DogDomain() {
                this.name = '';
                this.indoors = true;
                this.imagePath = '';
                this.placeObjects = [];
            }
            return DogDomain;
        }());
        virtdog.DogDomain = DogDomain;
    })(virtdog = dogsrus.virtdog || (dogsrus.virtdog = {}));
})(dogsrus || (dogsrus = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZG9nRG9tYWluLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZG9nRG9tYWluLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFlBQVksQ0FBQztBQUNiLElBQVUsT0FBTyxDQU9oQjtBQVBELFdBQVUsT0FBTztJQUFDLElBQUEsT0FBTyxDQU94QjtJQVBpQixXQUFBLE9BQU8sRUFBQyxDQUFDO1FBQ3pCO1lBQUE7Z0JBQ1MsU0FBSSxHQUFHLEVBQUUsQ0FBQztnQkFDVixZQUFPLEdBQUcsSUFBSSxDQUFDO2dCQUNmLGNBQVMsR0FBRyxFQUFFLENBQUM7Z0JBQ2YsaUJBQVksR0FBZ0IsRUFBRSxDQUFDO1lBQ3hDLENBQUM7WUFBRCxnQkFBQztRQUFELENBQUMsQUFMRCxJQUtDO1FBTFksaUJBQVMsWUFLckIsQ0FBQTtJQUNILENBQUMsRUFQaUIsT0FBTyxHQUFQLGVBQU8sS0FBUCxlQUFPLFFBT3hCO0FBQUQsQ0FBQyxFQVBTLE9BQU8sS0FBUCxPQUFPLFFBT2hCIn0=