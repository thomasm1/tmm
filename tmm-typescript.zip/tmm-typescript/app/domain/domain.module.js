'use strict';
var dogsrus;
(function (dogsrus) {
    var virtdog;
    (function (virtdog) {
        angular.module('app.dogDomain', []);
        function getModuleDogDomain() {
            return angular.module('app.dogDomain');
        }
        virtdog.getModuleDogDomain = getModuleDogDomain;
    })(virtdog = dogsrus.virtdog || (dogsrus.virtdog = {}));
})(dogsrus || (dogsrus = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZG9tYWluLm1vZHVsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRvbWFpbi5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsWUFBWSxDQUFDO0FBQ2IsSUFBVSxPQUFPLENBS2hCO0FBTEQsV0FBVSxPQUFPO0lBQUMsSUFBQSxPQUFPLENBS3hCO0lBTGlCLFdBQUEsT0FBTyxFQUFDLENBQUM7UUFDekIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDcEM7WUFDRSxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUN6QyxDQUFDO1FBRmUsMEJBQWtCLHFCQUVqQyxDQUFBO0lBQ0gsQ0FBQyxFQUxpQixPQUFPLEdBQVAsZUFBTyxLQUFQLGVBQU8sUUFLeEI7QUFBRCxDQUFDLEVBTFMsT0FBTyxLQUFQLE9BQU8sUUFLaEIifQ==