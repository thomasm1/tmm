'use strict';
var dogsrus;
(function (dogsrus) {
    var virtdog;
    (function (virtdog) {
        angular.module('app.dog', []);
        function getModuleDog() {
            return angular.module('app.dog');
        }
        virtdog.getModuleDog = getModuleDog;
    })(virtdog = dogsrus.virtdog || (dogsrus.virtdog = {}));
})(dogsrus || (dogsrus = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZG9nLm1vZHVsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImRvZy5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsWUFBWSxDQUFDO0FBQ2IsSUFBVSxPQUFPLENBS2hCO0FBTEQsV0FBVSxPQUFPO0lBQUMsSUFBQSxPQUFPLENBS3hCO0lBTGlCLFdBQUEsT0FBTyxFQUFDLENBQUM7UUFDekIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDOUI7WUFDRSxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNuQyxDQUFDO1FBRmUsb0JBQVksZUFFM0IsQ0FBQTtJQUNILENBQUMsRUFMaUIsT0FBTyxHQUFQLGVBQU8sS0FBUCxlQUFPLFFBS3hCO0FBQUQsQ0FBQyxFQUxTLE9BQU8sS0FBUCxPQUFPLFFBS2hCIn0=