﻿'use strict';
namespace dogsrus.virtdog {
  angular.module('app.dog', []);
  export function getModuleDog(): ng.IModule {
    return angular.module('app.dog');
  }
}
