'use strict';
var dogsrus;
(function (dogsrus) {
    var virtdog;
    (function (virtdog) {
        (function (DogTailState) {
            DogTailState[DogTailState["wagging"] = 0] = "wagging";
            DogTailState[DogTailState["elevated"] = 1] = "elevated";
            DogTailState[DogTailState["drooped"] = 2] = "drooped";
            DogTailState[DogTailState["tucked"] = 3] = "tucked";
        })(virtdog.DogTailState || (virtdog.DogTailState = {}));
        var DogTailState = virtdog.DogTailState;
    })(virtdog = dogsrus.virtdog || (dogsrus.virtdog = {}));
})(dogsrus || (dogsrus = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiSURvZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIklEb2cudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsWUFBWSxDQUFDO0FBQ2IsSUFBVSxPQUFPLENBMEJoQjtBQTFCRCxXQUFVLE9BQU87SUFBQyxJQUFBLE9BQU8sQ0EwQnhCO0lBMUJpQixXQUFBLE9BQU8sRUFBQyxDQUFDO1FBQ3pCLFdBQVksWUFBWTtZQUN0QixxREFBTyxDQUFBO1lBQ1AsdURBQVEsQ0FBQTtZQUNSLHFEQUFPLENBQUE7WUFDUCxtREFBTSxDQUFBO1FBQ1IsQ0FBQyxFQUxXLG9CQUFZLEtBQVosb0JBQVksUUFLdkI7UUFMRCxJQUFZLFlBQVksR0FBWixvQkFLWCxDQUFBO0lBb0JILENBQUMsRUExQmlCLE9BQU8sR0FBUCxlQUFPLEtBQVAsZUFBTyxRQTBCeEI7QUFBRCxDQUFDLEVBMUJTLE9BQU8sS0FBUCxPQUFPLFFBMEJoQiJ9