'use strict';
var dogsrus;
(function (dogsrus) {
    var virtdog;
    (function (virtdog) {
        angular.module('app.people', []);
        function getModulePeople() {
            return angular.module('app.people');
        }
        virtdog.getModulePeople = getModulePeople;
    })(virtdog = dogsrus.virtdog || (dogsrus.virtdog = {}));
})(dogsrus || (dogsrus = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGVvcGxlLm1vZHVsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInBlb3BsZS5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsWUFBWSxDQUFDO0FBQ2IsSUFBVSxPQUFPLENBS2hCO0FBTEQsV0FBVSxPQUFPO0lBQUMsSUFBQSxPQUFPLENBS3hCO0lBTGlCLFdBQUEsT0FBTyxFQUFDLENBQUM7UUFDekIsT0FBTyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDakM7WUFDRSxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUN0QyxDQUFDO1FBRmUsdUJBQWUsa0JBRTlCLENBQUE7SUFDSCxDQUFDLEVBTGlCLE9BQU8sR0FBUCxlQUFPLEtBQVAsZUFBTyxRQUt4QjtBQUFELENBQUMsRUFMUyxPQUFPLEtBQVAsT0FBTyxRQUtoQiJ9