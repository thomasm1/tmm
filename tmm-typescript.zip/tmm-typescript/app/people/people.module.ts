﻿'use strict';
namespace dogsrus.virtdog {
  angular.module('app.people', []);
  export function getModulePeople(): ng.IModule {
    return angular.module('app.people');
  }
}
