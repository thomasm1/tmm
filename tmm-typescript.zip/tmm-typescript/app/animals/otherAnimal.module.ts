﻿'use strict';
namespace dogsrus.virtdog {
  angular.module('app.otherAnimal', []);
  export function getModuleOtherAnimal(): ng.IModule {
    return angular.module('app.otherAnimal');
  }
}
