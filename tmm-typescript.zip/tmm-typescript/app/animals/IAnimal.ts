﻿namespace dogsrus.virtdog {
  export interface IAnimal {
    defaultAction: string;
    familiarName?: string;
    speciesName: string;
  }
}
