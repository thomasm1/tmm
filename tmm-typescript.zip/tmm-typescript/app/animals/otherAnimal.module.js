'use strict';
var dogsrus;
(function (dogsrus) {
    var virtdog;
    (function (virtdog) {
        angular.module('app.otherAnimal', []);
        function getModuleOtherAnimal() {
            return angular.module('app.otherAnimal');
        }
        virtdog.getModuleOtherAnimal = getModuleOtherAnimal;
    })(virtdog = dogsrus.virtdog || (dogsrus.virtdog = {}));
})(dogsrus || (dogsrus = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3RoZXJBbmltYWwubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsib3RoZXJBbmltYWwubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFlBQVksQ0FBQztBQUNiLElBQVUsT0FBTyxDQUtoQjtBQUxELFdBQVUsT0FBTztJQUFDLElBQUEsT0FBTyxDQUt4QjtJQUxpQixXQUFBLE9BQU8sRUFBQyxDQUFDO1FBQ3pCLE9BQU8sQ0FBQyxNQUFNLENBQUMsaUJBQWlCLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDdEM7WUFDRSxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQzNDLENBQUM7UUFGZSw0QkFBb0IsdUJBRW5DLENBQUE7SUFDSCxDQUFDLEVBTGlCLE9BQU8sR0FBUCxlQUFPLEtBQVAsZUFBTyxRQUt4QjtBQUFELENBQUMsRUFMUyxPQUFPLEtBQVAsT0FBTyxRQUtoQiJ9